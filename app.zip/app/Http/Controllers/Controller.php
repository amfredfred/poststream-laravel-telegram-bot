<?php

namespace App\Http\Controllers;

use App\Helpers\ResponseHelper;

abstract class Controller extends ResponseHelper {
    //
}
